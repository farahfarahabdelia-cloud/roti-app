// Service worker minimal: supaya bisa di-install sebagai aplikasi. Data selalu dari server.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => { if (e.request.method === 'GET' && !e.request.url.includes('/api/')) e.respondWith(fetch(e.request).catch(() => caches.match(e.request))); });
